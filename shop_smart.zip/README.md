# shop_smart
A responsive user friendly e commerce store (shop smart)
